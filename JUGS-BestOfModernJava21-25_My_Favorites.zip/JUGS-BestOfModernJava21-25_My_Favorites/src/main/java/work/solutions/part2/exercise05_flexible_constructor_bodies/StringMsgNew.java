package work.solutions.exercise2_Statements_Before_Super;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/2025 by Michael Inden
 */
public class StringMsgNew extends PlainByteMsg {

    public StringMsgNew(final String payload) {
        if (payload == null)
            throw new IllegalArgumentException("payload should not be null");

        final String doubledPayload = heavyStringTransformation(payload);
        final byte[] convertedPayload = convertToByteArray(doubledPayload);
        
        super(convertedPayload);
    }

    private static String heavyStringTransformation(String input) {
        return input.repeat(2);
    }

    // Auxiliary method
    private static byte[] convertToByteArray(final String payload) {
        return switch (payload) {
            case "AA" -> new byte[]{1, 2, 3, 4};
            case "BBBB" -> new byte[]{7, 2, 7, 1};
            default -> payload.getBytes();
        };
    }

    public static void main(String[] args) {
        System.out.println(new StringMsgNew("A"));
        System.out.println(new StringMsgNew("BB"));
        System.out.println(new StringMsgNew("HELLO SOPHIE"));
        System.out.println(new StringMsgNew(null));
    }
}