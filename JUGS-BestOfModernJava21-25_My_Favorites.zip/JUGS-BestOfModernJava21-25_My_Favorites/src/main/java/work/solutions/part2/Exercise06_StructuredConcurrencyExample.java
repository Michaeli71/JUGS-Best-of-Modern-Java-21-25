package work.solutions.part2;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.StructuredTaskScope;
import java.util.concurrent.StructuredTaskScope.Subtask;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/2025 by Michael Inden
 */
public class Exercise06_StructuredConcurrencyExample {

    public static void main(final String[] args) throws ExecutionException, InterruptedException {

        executeTasks(false);

        executeTasks(true);
    }

    private static void executeTasks(boolean forceFailure) throws InterruptedException, ExecutionException {

        //var joiner = StructuredTaskScope.Joiner.awaitAllSuccessfulOrThrow();
        try (var scope = StructuredTaskScope.open()) {

            var task1 = scope.fork(() -> {
                // Abbruch im Falle von "forceFailure" => dann erfolgt Ausgabe nicht mehr
                Thread.sleep(1000);
                System.out.println("executing task1");
                return "1";
            });

            Subtask<String> task2 = scope.fork(() -> {
                if (forceFailure)
                    throw new IllegalStateException("FORCED BUG");

                return "2";
            });

            Subtask<String> task3 = scope.fork(() -> {
                return "3";
            });

            scope.join();

            System.out.println(task1.get());
            System.out.println(task2.get());
            System.out.println(task3.get());
        }
    }
}
