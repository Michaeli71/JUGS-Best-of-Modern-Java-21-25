package work.solutions.part1;

import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023, 2024 by Michael Inden
 */
public class Exercise03_ThreadingExample {
public static void main(final String[] args) {
    try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
        IntStream.range(0, 1_000_000).forEach(i -> {
            executor.submit(() -> {
                Thread.sleep(Duration.ofSeconds(2));

                boolean isVirtual = Thread.currentThread().isVirtual();
                System.out.println("Task " + i + " finished! " +
                                   "isVirtual = " + isVirtual);
                return i;
            });
        });
    }

    System.out.println("FINISHED");
}
}
