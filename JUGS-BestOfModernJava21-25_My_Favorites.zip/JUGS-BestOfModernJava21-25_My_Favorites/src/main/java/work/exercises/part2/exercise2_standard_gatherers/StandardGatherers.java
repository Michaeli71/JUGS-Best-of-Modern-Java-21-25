package work.exercises.part2.exercise2_standard_gatherers;

import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class StandardGatherers {
    public static void main(String[] args) {
        var crossMult = Stream.of(1, 2, 3, 4, 5, 6, 7);
                               // TODO

        //  crossMult ==> Optional[5040]

        var values = Stream.of(1, 2, 3, 10, 20, 30, 100, 200, 300);
        // TODO
        // [[1, 2, 3], [10, 20, 30], [100, 200, 300]]
    }
}
