package work.exercises.exercise1_Statements_Before_Super;

import java.awt.*;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/2025 by Michael Inden
 */
public class ColoredShape {
    private final Color color;
    private final int x;
    private final int y;

    public ColoredShape(Color color, int x, int y) {
        this.color = color;
        this.x = x;
        this.y = y;
    }
}

