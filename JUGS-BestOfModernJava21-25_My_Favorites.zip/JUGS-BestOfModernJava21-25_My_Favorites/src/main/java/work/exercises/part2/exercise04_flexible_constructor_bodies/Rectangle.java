package work.exercises.exercise1_Statements_Before_Super;

import java.awt.*;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/2025 by Michael Inden
 */
public class Rectangle extends ColoredShape {
    private final int width;
    private final int height;

    public Rectangle(Color color, int x, int y, int width, int height) {
        super(color, x, y);

        if (width < 1 || height < 1)
            throw new IllegalArgumentException("width and height must be positive");

        this.width = width;
        this.height = height;
    }
}