package java25.jep505_structured_concurrency;

import java.util.List;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.StructuredTaskScope;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23/24" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23/24"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25 by Michael Inden
 */
public class OwnJoinersExample {
    public static void main(final String[] args) throws ExecutionException, InterruptedException {
        justSuccesful();
        firstNSuccessful(4);
        firstNSuccessfulV2(4);
        meetsCondition((NetworkConnection val) -> val.type().contains("5G") || val.type().contains("4G"));
    }

    record NetworkConnection(String type) {
    }

    public static void justSuccesful() throws InterruptedException {
        JustSuccessful<NetworkConnection> joiner = new JustSuccessful<>();
        try (var scope = StructuredTaskScope.open(joiner)) {

            var result1 = scope.fork(() -> tryToGetWifi());
            var result2 = scope.fork(() -> tryToGet5g());
            var result3 = scope.fork(() -> tryToGet4g());
            var result4 = scope.fork(() -> tryToGet3g());
            var result5 = scope.fork(() -> tryToGet2gEdge());

            var result = scope.join().toList();

            System.out.println("found connection: " + result);
        }
    }

    public static void firstNSuccessful(int maxCount) throws InterruptedException {
        FirstNSuccessful<NetworkConnection> joiner = new FirstNSuccessful<>(maxCount);
        try (var scope = StructuredTaskScope.open(joiner))
        {
            var result1 = scope.fork(() -> tryToGetWifi());
            var result2 = scope.fork(() -> tryToGet5g());
            var result3 = scope.fork(() -> tryToGet4g());
            var result4 = scope.fork(() -> tryToGet3g());
            var result5 = scope.fork(() -> tryToGet2gEdge());

            var result = scope.join().toList();

            System.out.println("found connection: " + result);
        }
    }

    public static void firstNSuccessfulV2(int maxCount) throws InterruptedException {
        FirstNSuccessfulV2<NetworkConnection> joiner = new FirstNSuccessfulV2<>(maxCount);
        try (var scope = StructuredTaskScope.open(joiner))
        {
            var result1 = scope.fork(() -> tryToGetWifi());
            var result2 = scope.fork(() -> tryToGet5g());
            var result3 = scope.fork(() -> tryToGet4g());
            var result4 = scope.fork(() -> tryToGet3g());
            var result5 = scope.fork(() -> tryToGet2gEdge());

            var result = scope.join().toList();

            System.out.println("found connection: " + result);
        }
    }

    public static void meetsCondition(Predicate<NetworkConnection> predicate) throws InterruptedException
    {
        MeetsCondition<NetworkConnection> joiner = new MeetsCondition<>(predicate);

        try (var scope = StructuredTaskScope.open(joiner))
        {
            var result1 = scope.fork(() -> tryToGetWifi());
            var result2 = scope.fork(() -> tryToGet5g());
            var result3 = scope.fork(() -> tryToGet4g());
            var result4 = scope.fork(() -> tryToGet3g());
            var result5 = scope.fork(() -> tryToGet2gEdge());

            var result = scope.join().toList();

            System.out.println("found connections: " + result);
        }
    }

    private static NetworkConnection tryToGet3g() throws InterruptedException {
        sleepRandomlyUpToTwoSecs();
        return new NetworkConnection("3G");
    }

    private static void sleepRandomlyUpToOneSec() throws InterruptedException {
        Thread.sleep((long) (1000 * Math.random()));
    }

    private static NetworkConnection tryToGet4g() throws InterruptedException {
        sleepRandomlyUpToTwoSecs();
        return new NetworkConnection("4G");
    }

    private static NetworkConnection tryToGet5g() throws InterruptedException {
        sleepRandomlyUpToTwoSecs();
        return new NetworkConnection("5G");
    }

    private static NetworkConnection tryToGetWifi() throws InterruptedException {
        sleepRandomlyUpToTwoSecs();
        return new NetworkConnection("Wifi");
    }

    private static NetworkConnection tryToGet2gEdge() throws InterruptedException {
        sleepRandomlyUpToTwoSecs();
        return new NetworkConnection("2G (Edge)");
    }

    private static void sleepRandomlyUpToTwoSecs() throws InterruptedException {
        Thread.sleep((long) (1000 + 1000 * Math.random()));
        if (Math.random() < 0.1) {
            throw new IllegalStateException("FORCED PROBLEM");
        }
    }


    static class JustSuccessful<T> implements StructuredTaskScope.Joiner<T, Stream<T>> {

        private final List<T> allSuccesfulResults = new CopyOnWriteArrayList<>();

        @Override
        public boolean onComplete(StructuredTaskScope.Subtask<? extends T> subtask) {
            if (subtask.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                allSuccesfulResults.add(subtask.get());
            }
            return false;
        }

        @Override
        public Stream<T> result() {
            return allSuccesfulResults.stream();
        }
    }

    static class FirstNSuccessful<T> implements StructuredTaskScope.Joiner<T, Stream<T>> {

        private final int maxResults;

        private final AtomicInteger successCount = new AtomicInteger();

        private final List<T> firstSuccesfulResults = new CopyOnWriteArrayList<>();

        public FirstNSuccessful(int maxResults) {
            this.maxResults = maxResults;
        }

        @Override
        public boolean onComplete(StructuredTaskScope.Subtask<? extends T> subtask) {
            if (subtask.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                firstSuccesfulResults.add(subtask.get());
                if (successCount.incrementAndGet() == maxResults) {
                    return true;
                }
            }
            return false;
        }

        @Override
        public Stream<T> result() {
            return firstSuccesfulResults.stream().limit(maxResults);
        }
    }

    static class FirstNSuccessfulV2<T> implements StructuredTaskScope.Joiner<T, Stream<T>> {

        private final int maxResults;

        private final List<T> firstSuccesfulResults = new CopyOnWriteArrayList<>();

        public FirstNSuccessfulV2(int maxResults) {
            this.maxResults = maxResults;
        }

        @Override
        public boolean onComplete(StructuredTaskScope.Subtask<? extends T> subtask) {
            if (subtask.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                firstSuccesfulResults.add(subtask.get());
                if (firstSuccesfulResults.size() >= maxResults) {
                    return true;
                }
            }
            return false;
        }

        @Override
        public Stream<T> result() {
            return firstSuccesfulResults.stream().limit(maxResults);
        }
    }

static class MeetsCondition<T> implements StructuredTaskScope.Joiner<T, Stream<T>> {

    private final Predicate<? super T> predicate;

    private final Queue<T> matchingSuccessfulResults =
                           new ConcurrentLinkedQueue<>();

    public MeetsCondition(Predicate<? super T> predicate) {
        this.predicate = Objects.requireNonNull(predicate, "predicate");
    }

    @Override
    public boolean onComplete(StructuredTaskScope.Subtask<? extends T> subtask) {
        if (subtask.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
            T result = subtask.get();
            if (predicate.test(result)) {
                matchingSuccessfulResults.add(result);
            }
        }
        return false; // nie vorzeitig abbrechen
    }

    @Override
    public Stream<T> result() {
        return matchingSuccessfulResults.stream();
    }
}



    // Macht eigentlich keinen Sinn
    static class JustFailing<T> implements StructuredTaskScope.Joiner<T, Stream<StructuredTaskScope.Subtask<? extends T>>> {

        private final List<StructuredTaskScope.Subtask<? extends T>> allFailingResults = new CopyOnWriteArrayList<>();

        public boolean onComplete(StructuredTaskScope.Subtask<? extends T> subtask) {
            if (subtask.state() != StructuredTaskScope.Subtask.State.SUCCESS) {
                allFailingResults.add(subtask);
            }
            return false;
        }

        public Stream<StructuredTaskScope.Subtask<? extends T>> result() {
            return allFailingResults.stream();
        }
    }
}