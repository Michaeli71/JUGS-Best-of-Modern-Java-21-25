package java25.jep458_Launch_MultiFile_SourceCode_Programs;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
class Helper
{
    public static String performCalaulcation() {
        return "Heavy, long running calculation!";
    }
}