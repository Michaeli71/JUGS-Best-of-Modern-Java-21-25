void main() throws IOException
{
    var name = IO.readln("Please enter your name: ");
    var age = Integer.parseInt(IO.readln("Please enter your age: "));
    var today = LocalDate.now();

    var info = """
            Hello, %s!
            Today is %s
            Your current age is %d
            """.formatted(name, today, age);
    IO.println(info);

    Path infoFile = Paths.get(name+".txt");
    Files.writeString(infoFile, info);

    String content = Files.readString(infoFile);
    Stream<String> asStream = content.lines();

    List<String> lines = asStream.collect(Collectors.toUnmodifiableList());
    IO.println(lines);
}