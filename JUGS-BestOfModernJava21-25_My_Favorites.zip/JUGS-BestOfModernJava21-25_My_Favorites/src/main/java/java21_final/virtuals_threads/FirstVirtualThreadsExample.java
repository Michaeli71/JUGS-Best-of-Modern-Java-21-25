package java21_final.virtuals_threads;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class FirstVirtualThreadsExample
{
    public static void main(String[] args) throws InterruptedException
    {
        Runnable action = () -> {
            var currentThread = Thread.currentThread();
            System.out.println("name: " + currentThread.getName() +
                                               " isVirtual(): " + currentThread.isVirtual());
        };

        var platformThread = Thread.ofPlatform().name("myPlatform").unstarted(action);
        platformThread.start();

        var virtualThread = Thread.ofVirtual().name("myFirstVirtual").unstarted(action);
        virtualThread.start();

        virtualThread.join();
        System.out.println("is Thread? " + (virtualThread instanceof Thread));

        Thread.startVirtualThread(action);
    }
}
