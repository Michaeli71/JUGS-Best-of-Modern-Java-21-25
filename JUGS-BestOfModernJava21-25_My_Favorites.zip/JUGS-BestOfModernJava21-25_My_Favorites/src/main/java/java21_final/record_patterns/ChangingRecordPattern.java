package java21_final.record_patterns;

public class ChangingRecordPattern {

    // Change Signature
    // => passt Record und Pattern Deconstructions an sowie Konstruktionen durch Defaultwert
    // Änderung per Hand führt zu potenziell vielen Kompilierfehlern
    record Data(String name, int age, String info) {}

    public static void main(String[] args) {

        Data data = new Data("Mike", 23, "info");

        switch (data)
        {
            case Data(String name, var age, String info) when name.equals("Mike") && age == 23 -> System.out.println("Name and age match");
            case Data(String name, var age, String info) when name.equals("Mike") && age != 23 -> System.out.println("Name matches but age does not");
            case Data(String name, var age, String info) when name != "Mike" && age == 23-> System.out.println("Name does not match but age matches");
            default -> System.out.println("No match");
        }
    }
}
